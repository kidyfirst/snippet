#!/bin/sh
cd `dirname $0`
sh safe_server.sh stop
