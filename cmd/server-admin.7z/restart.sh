#!/bin/sh
cd `dirname $0`
sh safe_server.sh stop
sleep 1
sh safe_server.sh start

