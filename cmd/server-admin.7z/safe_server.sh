#!/bin/sh
################################
#     write by paterzheng    200601
#	  edit by toyboxzhou     201106
################################

cd -P `dirname $0`
export NODE_ENV=development

SYSNAME=node
CHANNEL_SERVER_PATH=`pwd`
NODEJS_HOME=`dirname ${CHANNEL_SERVER_PATH}`

# �޸Ľ�����Ϣ���
#./${SYSNAME}_server ../conf/${SYSNAME}_server.conf.xml
SERVER_CONF=../server.js
SERVER_PID=${CHANNEL_SERVER_PATH}/.${SYSNAME}.pid
CHANNEL_SERVER=node
user=`whoami`

function createpid {
		local name=`basename $0`
		pidfile="`pwd`/.${name}.pid"
        trap 'rm $pidfile; exit' INT TERM
        if [ -e $pidfile ];
        then
            local pid=`cat $pidfile`
			ps -p $pid -o 'args='|grep -w ${name}|grep -Ev "^vi |^vim |^grep"
            if [ $? -eq 0 ]; then
               echo "$0 has already there, exit..."
               exit
            fi
        fi
        echo $$ > $pidfile
		if [ $? -ne 0 ];then
			echo "create pid file error,exit."
			exit 1
		fi
}

function GetPid()
{
  local psn=""
  if [ -f ${SERVER_PID} ] ;then
    read PROC_ID < ${SERVER_PID}
	ps -fp $PROC_ID|grep "${CHANNEL_SERVER}"|grep -v grep
	[ $? -ne 0 ] && PROC_ID=0
  else
    PROC_ID=0
  fi
  #[ "$PROC_ID" == "0" ] && psn=`ps -u $user x -o 'ppid,pid,args'|grep -w "${CHANNEL_SERVER}"|awk '{if($1 == 1) print $2}'`
  [ "$PROC_ID" == "0" ] && psn=`ps -u $user x -o 'ppid,pid,args'|grep -w "${CHANNEL_SERVER}"|awk '{if($1 == 1) print $2}'`
  [ "$psn" != "" ] && PROC_ID=$psn
}

function Stop()
{
  GetPid
  if test "$PROC_ID" == "0"; then
    echo "$(date) can't get ${CHANNEL_SERVER} pid ,is it really running?"
  else
    #cd ${CHANNEL_SERVER_PATH};./${CHANNEL_SERVER} -c ${SERVER_CONF} -s
	killall -12 ${CHANNEL_SERVER}
    echo "$(date) killing $PROC_ID"
  fi
  [ -f ${SERVER_PID} ] && rm ${SERVER_PID}
  sleep 0.2 ; killall -9 ${CHANNEL_SERVER} >/dev/null 2>&1
}

function Boot()
{
    ulimit -c unlimited
    cd ${CHANNEL_SERVER_PATH};./${CHANNEL_SERVER}  ${SERVER_CONF} & 
    echo "$(date) booting ${CHANNEL_SERVER}"
}

function Start()
{
  GetPid
  if test "$PROC_ID" == "0"; then
    Boot
  else
      echo "$(date) ${CHANNEL_SERVER} pid already exist, pid: $PROC_ID"
  fi
}

function Reboot()
{
  Stop
  sleep 1
  Start
}


function Proc(){
	#pids=`ps -u $user x -o 'ppid,pid,args'|grep -w "${CHANNEL_SERVER}"|awk '{if($1 == 1) print $2}'`
	pids=`ps -u $user x -o 'ppid,pid,args'|grep -w "${CHANNEL_SERVER}"|awk '{if($1 == 1) print $2}'`
	if [ "$pids" != "" ];then
		echo "${CHANNEL_SERVER} running ,pid=${pids}"
	else
		echo "${CHANNEL_SERVER} not running"
	fi
}

case "$1" in
	start)
		Start
	;;
	stop)
		Stop
	;;
	reboot|restart)
		Reboot
	;;
	status)
		Proc
	;;

	*)
		echo "usage $0 start|stop|reboot|restart|status"
esac

exit 0

